# c7-SCS-Infra
This repo contains the New CCP Infrastructure as code using Terraform and using AWS as the cloud provider.
# Reporting a bug
Use the github issues to report an Issue.
