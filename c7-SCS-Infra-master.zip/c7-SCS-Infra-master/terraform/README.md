# c7-SCS-Infra

## Dev-infra
The terraform scripts creates the desired number of instances in the cluster.

The current cluster for the developers is as below:

 S.No. | Name | Username | workstation_ip | backend_ip 
-------|------|----------|----------------|------------
1	|Jiri Simek	|simejir | 10.112.38.211 | 10.112.36.196 
2	|Michal Jancok	|jancmic|	10.112.38.112|	10.112.40.167
3	|David Stegbauer	|stegdav|	10.112.44.105|	10.112.42.104
4	|Javier Acosta|	acosjav|	10.112.32.132|	10.112.36.35
5	|Martin Lahuta|	lahumar|	10.112.36.18|	10.112.35.29
6	|Bengt Haarbrandt|	haarben|	10.112.35.20|	10.112.43.88
7	|Srinivas Garidepally|	garisri|	10.112.32.61|	10.112.34.251
8	|Chetak Lad|	ladche1|	10.112.33.51|	10.112.46.231
9	|Varun Gada|	gadavar|	10.112.45.190|	10.112.33.228
10	|Rashmi Kodihalli|	kodiras|	10.112.44.198|	10.112.42.25
11	|Sandra Hofmann|	hofmsan|	10.112.46.208|	10.112.40.36
12	|Vidya Khairnar|	khaivid|	10.112.36.189|	10.112.35.139

+	To login to the workstation use RDP Client (available in Citrix App Launcher).
+	To login to the backend server use any ssh client like terminal or Putty.
+	The default password for all users is “Clearing2018!” (without double-quotes). 
+	All the instances automatically starts at 07:00 and stops at 22:00. (Timings can be modified anytime)
+	The instances will not automatically start on weekends. Can be manually started from AWS console.



## Openshift-infra
Work in progress
